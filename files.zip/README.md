# Gift Card Selling Site

A full-stack application to sell gift cards. Users add funds to a wallet, purchase gift cards, and admins can manage user accounts.

## Structure

- `client/`: React frontend
- `server/`: Express backend API

## Quickstart

1. Clone this repo
2. See `client/` and `server/` directories for setup instructions

## Features

- Wallet deposit & balance
- Gift card marketplace
- Admin controls: freeze/ban users, add money

## Deployment

You can deploy with [Render](https://render.com/), [Heroku](https://heroku.com/), or Vercel/Netlify for the frontend.