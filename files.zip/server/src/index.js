import express from "express";
import cors from "cors";

const app = express();
app.use(express.json());
app.use(cors());

let users = [];
let giftCards = [];
let admins = [
  { username: "admin", password: "adminpass", role: "admin" }
];

// Simple routes (replace with DB, add auth in production)
app.get("/", (req, res) => res.send("Gift Card API running"));

app.listen(process.env.PORT || 3000, () =>
  console.log("Backend API running")
);

/* Add routes for:
- Register/Login
- Wallet deposit/purchase
- Admin freeze/ban/add money
- Gift card marketplace */