# Backend (`server/`)

## Setup

```bash
cd server
npm install
npm start
```

The backend uses environment variables from `.env` (see `.env.example`).