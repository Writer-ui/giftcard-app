# Frontend (`client/`)

## Setup

```bash
cd client
npm install
npm start
```

The frontend connects to the backend API via `REACT_APP_API_URL` in your `.env`.