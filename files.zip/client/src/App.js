import React, { useState } from "react";

function App() {
  return (
    <div>
      <h1>Gift Card Marketplace</h1>
      <p>Welcome! Use your wallet to buy gift cards.</p>
      {/* Add login/register, wallet, admin and gift card components here */}
    </div>
  );
}

export default App;