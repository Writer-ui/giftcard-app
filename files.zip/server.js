const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const app = express();
app.use(express.json());

const users = []; // In-memory for demo, use persistent DB in production
const giftCards = [];
const admins = [{ username: 'admin', password: bcrypt.hashSync('adminpass', 10), role: 'admin' }];

// Middleware to check for admin status
function isAdmin(req, res, next) {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).send('Unauthorized');
    try {
        const user = jwt.verify(token, 'secret');
        if (user.role !== 'admin') return res.status(403).send('Forbidden');
        next();
    } catch (e) {
        res.status(401).send('Invalid token');
    }
}

// Register user
app.post('/register', (req, res) => {
    const { username, password } = req.body;
    const hashed = bcrypt.hashSync(password, 10);
    users.push({ id: users.length + 1, username, password: hashed, wallet: 0, status: 'active' });
    res.status(201).json({ message: "User registered" });
});

// Login for users/admins
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username) || admins.find(a => a.username === username);
    if (!user || !bcrypt.compareSync(password, user.password)) return res.status(401).send('Invalid credentials');
    const token = jwt.sign({ id: user.id, username: user.username, role: user.role || 'user' }, 'secret');
    res.json({ token });
});

// Deposit money into wallet
app.post('/wallet/deposit', (req, res) => {
    // You'd integrate a payment gateway here
    const { userId, amount } = req.body;
    const user = users.find(u => u.id === userId);
    if (!user) return res.status(404).send('User not found');
    user.wallet += amount;
    res.json({ balance: user.wallet });
});

// Buy gift card with wallet
app.post('/giftcard/buy', (req, res) => {
    const { userId, giftCardId } = req.body;
    const user = users.find(u => u.id === userId);
    const card = giftCards.find(g => g.id === giftCardId && g.status === 'available');
    if (!user || !card) return res.status(404).send('User or card not found');
    if (user.wallet < card.price) return res.status(400).send('Insufficient balance');
    user.wallet -= card.price;
    card.status = 'sold';
    card.soldTo = user.id;
    res.json({ message: 'Purchase successful', card });
});

// Admin endpoint: Freeze user
app.post('/admin/freeze', isAdmin, (req, res) => {
    const { userId } = req.body;
    const user = users.find(u => u.id === userId);
    if (!user) return res.status(404).send('User not found');
    user.status = 'frozen';
    res.json({ message: 'User frozen' });
});

// Admin endpoint: Ban user
app.post('/admin/ban', isAdmin, (req, res) => {
    const { userId } = req.body;
    const user = users.find(u => u.id === userId);
    if (!user) return res.status(404).send('User not found');
    user.status = 'banned';
    res.json({ message: 'User banned' });
});

// Admin endpoint: Add money to wallet
app.post('/admin/addmoney', isAdmin, (req, res) => {
    const { userId, amount } = req.body;
    const user = users.find(u => u.id === userId);
    if (!user) return res.status(404).send('User not found');
    user.wallet += amount;
    res.json({ balance: user.wallet });
});

app.listen(3000, () => console.log('Server running on port 3000'));